export default interface ConfigurationInterface{
    id:number,
    mission:string,
    vision:string,
    address:string,
    email:string,
    phone:string,
    timetable:string
}