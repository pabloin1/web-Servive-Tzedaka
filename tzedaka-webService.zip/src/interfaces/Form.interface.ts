export default interface FormInterface {
    id:number,
    subject:string,
    full_name:string,
    phone:string,
    email:string,
    message:string,
    readed:boolean
}