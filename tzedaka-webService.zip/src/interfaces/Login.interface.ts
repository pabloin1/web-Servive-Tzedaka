export interface LoginInterface {
    email: string;
    password: string;
}
