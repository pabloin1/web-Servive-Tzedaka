export default interface UserInterface {
  id: number;
  email:string,
  name: string;
  password: string;
  token?: string;
}
