export default interface LoginInterface {
    email: string;
    password: string;
}
