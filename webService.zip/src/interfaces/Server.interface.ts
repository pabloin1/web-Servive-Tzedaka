interface ServerInterface {
    isProduction: boolean,
    PORT: string
}

export default ServerInterface;
