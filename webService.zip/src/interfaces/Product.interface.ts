export default interface ProductInterface{
    id:number,
    amount:number,
    description:string
}