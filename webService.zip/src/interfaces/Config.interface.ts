export interface ConfigType {
    dbHost: string;
    dbUser: string;
    dbPassword: string;
    dbName: string;
    jwtSecret: string;
}
