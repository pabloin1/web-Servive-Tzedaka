export default interface ResponseInterface {
  status: number;
  error: boolean;
  message: string;
  value: any;
}
